package Controlador;

import Modelo.*;
import config.GenerarSerie;
import java.io.IOException; 
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

public class Controlador extends HttpServlet {
    
    Empleado em = new Empleado();
    EmpleadoDAO edao = new EmpleadoDAO();
    Clientes cl = new Clientes();
    ClientesDAO cldao = new ClientesDAO();
    Producto pr = new Producto();
    ProductoDAO prdao = new ProductoDAO();
    int ide;
    
    Venta v = new Venta();
    List <Venta>lista = new ArrayList<>();
    int item=0;
    int cod;
    String descripcion;
    double precio;
    int cant;
    double subtotal;
    double totalPagar;
    
    String numeroserie;
    VentaDAO vdao = new VentaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if(menu.equals("Principal")){
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        }
        if(menu.equals("Empleado")){
            switch(accion){
                case "Listar":
                    List lista = edao.listar();
                    request.setAttribute("empleados", lista);
                    break;
                case "Agregar":
                    String dni = request.getParameter("txtDni");//se obtiene datos de caja de texto
                    String nom = request.getParameter("txtNombres");
                    String tel = request.getParameter("txtTel");
                    String est = request.getParameter("txtEstado");
                    String user = request.getParameter("txtUser");
                    em.setDni(dni);//se guardan en cada variable por medio de la clase empleado
                    em.setNom(nom);
                    em.setTel(tel);
                    em.setEstado(est);
                    em.setUser(user);
                    edao.agregar(em);//se gurdan datos de clase empleado en la bd por medio del metodo agregar de empleadoDAO
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Editar": 
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega del empleado.jsp
                    Empleado e = edao.listarId(ide);
                    request.setAttribute("empleado", e);//enaviar informacion al formulario Empleado.jsp
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Actualizar":
                    String dni1 = request.getParameter("txtDni");//se obtiene datos de caja de texto
                    String nom1 = request.getParameter("txtNombres");
                    String tel1 = request.getParameter("txtTel");
                    String estado1 = request.getParameter("txtEstado");
                    String user1 = request.getParameter("txtUser");
                    em.setDni(dni1);//se guardan en cada variable por medio de la clase empleado
                    em.setNom(nom1);
                    em.setTel(tel1);
                    em.setEstado(estado1);
                    em.setUser(user1);
                    em.setId(ide);
                    edao.actualizar(em);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Delete":
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega del empleado.jsp
                    edao.delete(ide);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("Empleado.jsp").forward(request, response);
        }
        if(menu.equals("Producto")){
           switch(accion){
                case "Listar":
                    List lista1 = prdao.listar();
                    request.setAttribute("productos", lista1);
                    break;
                case "Agregar":
                    String nom = request.getParameter("txtNom");//se obtiene datos de caja de texto
                    String pre = request.getParameter("txtPre");
                    String sto = request.getParameter("txtSto");
                    String estado = request.getParameter("txtEstado");
                    pr.setNom(nom);//se guardan en cada variable por medio de la clase empleado
                    pr.setPre(pre);
                    pr.setSto(sto);
                    pr.setEstado(estado);
                    prdao.agregar(pr);//se gurdan datos de clase producto en la bd por medio del metodo agregar de ProductoDAO
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Editar": 
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega del producto.jsp
                    Producto p = prdao.listarId(ide);
                    request.setAttribute("producto", p);//enaviar informacion al formulario Producto.jsp
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Actualizar":
                    String nom1 = request.getParameter("txtNom");//se obtiene datos de caja de texto
                    String pre1 = request.getParameter("txtPre");
                    String sto1 = request.getParameter("txtSto");
                    String estado1 = request.getParameter("txtEstado");
                    pr.setNom(nom1);//se guardan en cada variable por medio de la clase empleado
                    pr.setPre(pre1);
                    pr.setSto(sto1);
                    pr.setEstado(estado1);
                    pr.setId(ide);
                    prdao.actualizar(pr);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Delete":
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega del producto.jsp
                    prdao.delete(ide);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("Producto.jsp").forward(request, response);
        }
        if(menu.equals("Clientes")){
            switch(accion){
                case "Listar":
                    List lista2 = cldao.listar();
                    request.setAttribute("clientes", lista2);
                    break;
                case "Agregar":
                    String dni = request.getParameter("txtDni");//se obtiene datos de caja de texto
                    String nom = request.getParameter("txtNombres");
                    String dir = request.getParameter("txtDir");
                    String estado = request.getParameter("txtEstado");
                    cl.setDni(dni);//se guardan en cada variable por medio de la clase clientes
                    cl.setNom(nom);
                    cl.setDir(dir);
                    cl.setEstado(estado);
                    cldao.agregar(cl);//se gurdan datos de clase clientes en la bd por medio del metodo agregar de clientesDAO
                    request.getRequestDispatcher("Controlador?menu=Clientes&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Editar":
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega del clientes.jsp
                    Clientes c = cldao.listarId(ide);
                    request.setAttribute("cliente", c);//enviar informacion al formulario Clientes.jsp
                    request.getRequestDispatcher("Controlador?menu=Clientes&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Actualizar":
                    String dni2 = request.getParameter("txtDni");//se obtiene datos de caja de texto
                    String nom2 = request.getParameter("txtNombres");
                    String dir2 = request.getParameter("txtDir");
                    String estado2 = request.getParameter("txtEstado");
                    cl.setDni(dni2);//se guardan en cada variable por medio de la clase clientes
                    cl.setNom(nom2);
                    cl.setDir(dir2);
                    cl.setEstado(estado2);
                    cl.setId(ide);
                    cldao.actualizar(cl);
                    request.getRequestDispatcher("Controlador?menu=Clientes&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                case "Delete":
                    ide = Integer.parseInt(request.getParameter("id"));//guardando el id que llega de Clientes.jsp
                    cldao.delete(ide);
                    request.getRequestDispatcher("Controlador?menu=Clientes&accion=Listar").forward(request, response);//para actualizar la tabla con los nuevos datos
                    break;
                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("Clientes.jsp").forward(request, response);
        }
        if(menu.equals("RegistrarVenta")){
            switch(accion){
                case "BuscarCliente":
                    String dni = request.getParameter("codigocliente");
                    cl.setDni(dni);
                    cl = cldao.buscar(dni);
                    request.setAttribute("cl", cl);
                    break;
                case "BuscarProducto":
                    ide = Integer.parseInt(request.getParameter("codigoproducto"));//guardando el id que llega del producto.jsp
                    Producto p = prdao.listarId(ide);
                    request.setAttribute("cl", cl);
                    request.setAttribute("producto", p);//enviando datos al formulario
                    request.setAttribute("lista", lista);
                    request.setAttribute("totalpagar", totalPagar);
                    break;
                case "Agregar":
                    request.setAttribute("cl", cl);
                    totalPagar = 0.0;
                    item = item + 1;
                    //cod = pr.getId();
                    cod = Integer.parseInt(request.getParameter("codigoproducto"));//diferente
                    descripcion = request.getParameter("nomproducto");
                    precio = Double.parseDouble(request.getParameter("precio"));
                    cant = Integer.parseInt(request.getParameter("cant"));
                    subtotal = precio * cant;
                    v = new Venta();
                    v.setItem(item);
                    v.setIdproducto(cod);
                    v.setDescripcionP(descripcion);
                    v.setPrecio(precio);
                    v.setCantidad(cant);
                    v.setSubtotal(subtotal);
                    lista.add(v);
                    for (int i = 0; i < lista.size(); i++) {
                        totalPagar = totalPagar +lista.get(i).getSubtotal();//se esta almacenando la totalidad de todos los productos
                    }
                    request.setAttribute("totalpagar", totalPagar);
                    request.setAttribute("lista", lista);
                    break;
                case "GenerarVenta":
                    //Actualizacion del stock
                    for (int i = 0; i < lista.size(); i++) {
                        Producto pr = new Producto();
                        int cantidad = lista.get(i).getCantidad();
                        int idproducto = lista.get(i).getIdproducto();
                        ProductoDAO ao = new ProductoDAO();
                        pr = ao.buscar(idproducto);
                        int sac = Integer.parseInt(pr.getSto()) - cantidad;
                        ao.actualizarstock(idproducto, sac);
                    }
                    //Guardar venta
                    v.setIdcliente(cl.getId());
                    v.setIdempleado(2);
                    v.setNumserie(numeroserie);
                    v.setFecha("2019-06-14");
                    v.setMonto(totalPagar);
                    v.setEstado("1");
                    vdao.guardarVenta(v);
                    //Guardar detalle venta
                    int  idv = Integer.parseInt(vdao.IdVentas());
                    for (int i = 0; i < lista.size(); i++) {
                        v = new Venta();
                        v.setId(idv);
                        v.setIdproducto(lista.get(i).getIdproducto());
                        v.setCantidad(lista.get(i).getIdproducto());
                        v.setPrecio(lista.get(i).getPrecio());
                        vdao.guardarDetalleventas(v);
                    }
                    break;
                default:
                    v = new Venta();
                    lista = new ArrayList<>();
                    item = 0;
                    totalPagar = 0.0;
                    
                    numeroserie = vdao.GenerarSerie();//almacena el maximo numero de serie de la bd
                    if(numeroserie==null){
                        numeroserie="00000001";
                        request.setAttribute("nserie", numeroserie);
                    }else{
                        int incrementar = Integer.parseInt(numeroserie);
                        GenerarSerie gs = new GenerarSerie();
                        numeroserie = gs.Numeroserie(incrementar);
                        request.setAttribute("nserie", numeroserie);
                    }
                    request.getRequestDispatcher("RegistrarVenta.jsp").forward(request, response);
            }
            request.getRequestDispatcher("RegistrarVenta.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
